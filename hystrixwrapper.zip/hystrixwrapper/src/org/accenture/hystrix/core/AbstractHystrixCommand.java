package org.accenture.hystrix.core;

import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandKey;
import com.netflix.hystrix.HystrixEventType;
import com.netflix.hystrix.exception.HystrixRuntimeException;

import de.hybris.platform.core.Registry;
import de.hybris.platform.core.Tenant;

/**
 * This <tt>Class</tt> is tenant aware base representation of Hystrix commands,
 * for them client needs synchronous/asynchronous type of execution for their
 * service calls.Clients need to ensure first if they want command execution in
 * synchronous/asynchronous ways.
 *
 * @author Virendra Sharma
 *
 * @param <R>
 *            - A custom return type of command execution.
 * @see HystrixCommand
 */
public abstract class AbstractHystrixCommand<R> extends HystrixCommand<R> {

	private static final Logger LOGGER = LoggerFactory.getLogger(org.accenture.hystrix.core.AbstractHystrixCommand.class);

	private static final BiFunction<List<HystrixEventType>, HystrixEventType, Optional<HystrixEventType>> anyEventMatchFunction = (collection, toBeLooked) -> {
		if (CollectionUtils.isEmpty(collection)) {
			return Optional.empty();
		}
		return collection.stream().filter(event -> event == toBeLooked).findAny();
	};

	private final Tenant tenant;

	/**
	 * 
	 * Wrapping up commandGroupKey and commandKey in AbstractHystrixCommand.
	 * 
	 * @param commandGroupKey
	 *            - Hystrix collates all commands under this name for metrics ,
	 *            thread pool and caching purposes.
	 * @param commandKey
	 *            - name of the command.
	 */
	public AbstractHystrixCommand(final String commandGroupKey, final String commandKey) {
		super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey(commandGroupKey)).andCommandKey(HystrixCommandKey.Factory.asKey(commandKey)));
		this.tenant = Registry.getCurrentTenantNoFallback();
	}

	/**
	 * commandGroupKey wrapping up commandGroupKey and commandKey in
	 * AbstractHystrixCommand
	 * 
	 * @param commandGroupKey
	 *            -Hystrix collates all commands under this name for metrics ,
	 *            thread pool and caching purposes.
	 *
	 */
	public AbstractHystrixCommand(final String commandGroupKey) {
		super(HystrixCommandGroupKey.Factory.asKey(commandGroupKey));
		this.tenant = Registry.getCurrentTenantNoFallback();
	}

	/**
	 * {@inheritDoc}
	 *
	 */
	@Override
	protected final R run() throws Exception {
		if (Registry.hasCurrentTenant() && Registry.isCurrentTenant(tenant)) {
			return runCommand();
		}
		Registry.setCurrentTenant(tenant);
		try {
			return runCommand();
		} finally {
			Registry.unsetCurrentTenant();
		}
	}

	/**
	 * Local proxy method for {@link #run()}
	 */
	private R runCommand() throws Exception {
		if (!shouldCommandRun()) {
			return getFallback();
		}
		final StopWatch watch = new StopWatch();
		watch.start();
		auditBasicInfo();
		R result;
		try {
			result = this.doWork();
		} catch (final HystrixRuntimeException exception) {
			throw new CustomHystrixException(exception);
		} finally {
			watch.stop();
			auditExecutionInfo(watch);
		}
		return result;
	}

	/**
	 * One has to put its own implementation if he intends to execute it via
	 * <a href="https://github.com/Netflix/Hystrix/wiki">Hystrix</a>.
	 * 
	 * @throws Exception
	 * @return <R>
	 */
	public abstract R doWork() throws Exception;

	/**
	 * A custom fallback , in case exception occurs in {@link #run()} execution.
	 * Exception can be caused by end point unavailability , timeout etc.
	 *
	 * @return <R>
	 */
	public abstract R fallback();

	/**
	 * @return if command execution should happen.
	 */
	public abstract boolean shouldCommandRun();

	/**
	 * {@inheritDoc}
	 *
	 * @return <R>
	 */
	@Override
	protected final R getFallback() {
		auditFailure();
		return fallback();
	}

	/**
	 * Audits basic Hystrix command information.
	 */
	private void auditBasicInfo() {
		final StringBuilder buffer = new StringBuilder(12345);
		buffer.append(MessageFormat.format("Execution attempted for {0} command using {1} thread , spawned by Hystrix.", getCommandKey().name(),
				Thread.currentThread().getName()));
		buffer.append("Execution kicked off at ").append(LocalDateTime.now().toString());
		LOGGER.debug(buffer.toString());
	}

	/**
	 * Audits command execution info in case success occurs.
	 */
	private void auditExecutionInfo(final StopWatch watch) {
		final StringBuilder buffer = new StringBuilder(12345);
		buffer.append(MessageFormat.format("Completed {0} command execution in {1} milliseconds.", getCommandKey().name(), Long.valueOf(watch.getTime())));
		buffer.append(MessageFormat.format("Command execution finished at {0}", LocalDateTime.now().toString()));
		LOGGER.debug(buffer.toString());
	}

	/**
	 * Audits command Failure info
	 */
	private void auditFailure() {
		final StringBuilder buffer = new StringBuilder(12345);
		buffer.append("Fallback was called for ").append(getCommandKey().name()).append(" command execution.");

		anyEventMatchFunction.apply(getExecutionEvents(), HystrixEventType.FAILURE).ifPresent(event -> {
			buffer.append(MessageFormat.format("Exception occurred while {0} command execution.Exception traces are {1}", getCommandKey().name(),
					ExceptionUtils.getStackTrace(getExecutionException())));
		});
		anyEventMatchFunction.apply(getExecutionEvents(), HystrixEventType.EXCEPTION_THROWN).ifPresent(event -> {
			buffer.append(MessageFormat.format("Exception was thrown while {0} command execution.Exception traces are {1}", getCommandKey().name(),
					ExceptionUtils.getStackTrace(getExecutionException())));
		});
		anyEventMatchFunction.apply(getExecutionEvents(), HystrixEventType.THREAD_POOL_REJECTED).ifPresent(event -> {
			buffer.append(MessageFormat.format("Thread pool could not pick command for execution because of pool is gone out of capacity for {0}",
					getCommandKey().name()));
		});
		anyEventMatchFunction.apply(getExecutionEvents(), HystrixEventType.TIMEOUT).ifPresent(event -> {
			buffer.append("Failure occurred due to timeout.");
		});
		anyEventMatchFunction.apply(getExecutionEvents(), HystrixEventType.SHORT_CIRCUITED).ifPresent(event -> {
			buffer.append("Circuit breaker is open hence execution is not attempted");
		});
		LOGGER.error("Error occured in auditFailure() with buffer as {}",buffer.toString());
	}

	protected static String findCommandGroup(final String commandGroupKey) {
		final CommandGroup commandGroup = CommandGroup.fromString(commandGroupKey);
		return (commandGroup == CommandGroup.TEST_SERVICE) ? commandGroupKey : commandGroup.getCommandGroupKey();
	}
}
