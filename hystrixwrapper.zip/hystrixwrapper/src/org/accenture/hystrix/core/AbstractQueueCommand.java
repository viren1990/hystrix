
package org.accenture.hystrix.core;

import java.util.concurrent.Future;

import com.netflix.hystrix.HystrixCommand;

/**
 * Creator , if intends to have asynchronous execution of command , he must
 * extend his custom command class with this base class.
 *
 * A sample illustration to implement this is as given below. <br/>
 * <p>
 * <h1>public class SampleServiceCallCommand extends
 * AbstractQueueCommand<String>{ <br/>
 * &nbsp; &nbsp; public SampleServiceCallCommand(final String
 * commandGroupKey){<br/>
 * &nbsp; &nbsp;&nbsp; &nbsp; super(commandGroupKey);<br/>
 * &nbsp; &nbsp;}<br/>
 * &nbsp; &nbsp; public String doWrok() {<br/>
 * &nbsp; &nbsp;&nbsp; &nbsp;return "sample command response"; <br/>
 * &nbsp; &nbsp;}<br/>
 *
 * &nbsp; &nbsp; public String fallback(){<br/>
 * &nbsp; &nbsp;&nbsp; &nbsp; return "sample fallback called"; <br/>
 * &nbsp; &nbsp;}<br/>
 * }</h1>
 * </p>
 * <p>
 * Now Command caller will call it as follows;
 * <h1>public class SampleCommandCaller{<br/>
 * &nbsp; &nbsp;public static void main(String ar[]){<br/>
 *
 * &nbsp; &nbsp;&nbsp; &nbsp;final SampleServiceCallCommand command = new
 * SampleServiceCallCommand("sampleCommandGroupKey");<br/>
 *
 * &nbsp; &nbsp;&nbsp; &nbsp;final Future response = command.submit(); <br/>
 * &nbsp; &nbsp;&nbsp; &nbsp;System.out.println("Response is " +
 * response.get());<br/>
 *
 * &nbsp; &nbsp; }<br/>
 * }</h1>
 * </p>
 *
 * @author Virendra Sharma
 * @param <R>
 *            - A custom return type for command.
 *
 * @see AbstractHystrixCommand
 */
public abstract class AbstractQueueCommand<R> extends AbstractHystrixCommand<R> {

	/**
	 * Wrapping up commandGroupKey in findCommandGroup
	 * 
	 * @param commandGroupKey
	 */
	public AbstractQueueCommand(final String commandGroupKey) {
		super(findCommandGroup(commandGroupKey));
	}

	/**
	 * Wrapping up commandGroupKey and commandKey in findCommandGroup
	 * 
	 * @param commandGroupKey
	 * @param commandKey
	 */
	public AbstractQueueCommand(final String commandGroupKey, final String commandKey) {
		super(findCommandGroup(commandGroupKey), commandKey);
	}

	/**
	 * Caller has to call it to let command execution to happen in asynchronous
	 * fashion.
	 * <p>
	 * Asynchronous - {@link HystrixCommand#queue()} returns {@link Future} to
	 * calling thread , now it is client thread which has to block until it
	 * completes.
	 * </p>
	 *
	 * @return {@link Future}
	 */
	public final Future<R> submit() {
		return queue();

	}
}
