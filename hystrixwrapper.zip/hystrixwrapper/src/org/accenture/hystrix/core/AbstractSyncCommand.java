package org.accenture.hystrix.core;

import com.netflix.hystrix.HystrixCommand;

/**
 * Creator , if intends to have synchronous execution of command , he must
 * extend his custom command class with this base class.
 *
 * A sample illustration to implement this is as given below. <br/>
 * <p>
 * <h1>public class SampleServiceCallCommand extends
 * AbstractSyncCommand<String>{ <br/>
 * &nbsp; &nbsp; public SampleServiceCallCommand(final String
 * commandGroupKey){<br/>
 * &nbsp; &nbsp;&nbsp; &nbsp; super(commandGroupKey);<br/>
 * &nbsp; &nbsp;}<br/>
 * &nbsp; &nbsp; public String doWrok() {<br/>
 * &nbsp; &nbsp;&nbsp; &nbsp;return "sample command response"; <br/>
 * &nbsp; &nbsp;}<br/>
 *
 * &nbsp; &nbsp; public String fallback(){<br/>
 * &nbsp; &nbsp;&nbsp; &nbsp; return "sample fallback called"; <br/>
 * &nbsp; &nbsp;}<br/>
 * }</h1>
 * </p>
 * <p>
 * Now Command caller will call it as follows;
 * <h1>public class SampleCommandCaller{<br/>
 * &nbsp; &nbsp;public static void main(String ar[]){<br/>
 *
 * &nbsp; &nbsp;&nbsp; &nbsp;final SampleServiceCallCommand command = new
 * SampleServiceCallCommand("sampleCommandGroupKey");<br/>
 *
 * &nbsp; &nbsp;&nbsp; &nbsp;final String response = command.submit(); <br/>
 * &nbsp; &nbsp;&nbsp; &nbsp;System.out.println("Response is " + response);<br/>
 *
 * &nbsp; &nbsp; }<br/>
 * }</h1>
 * </p>
 *
 * @author Virendra Sharma
 *
 * @param <R>
 *            -A custom return type for command.
 *
 * @see AbstractHystrixCommand
 *
 */
public abstract class AbstractSyncCommand<R> extends AbstractHystrixCommand<R> {

	/**
	 * @param commandGroupKey
	 * 
	 */
	public AbstractSyncCommand(final String commandGroupKey) {
		super(findCommandGroup(commandGroupKey));
	}

	/**
	 * 
	 * @param commandGroupKey
	 * @param commandKey
	 * 
	 */
	public AbstractSyncCommand(final String commandGroupKey, final String commandKey) {
		super(findCommandGroup(commandGroupKey), commandKey);
	}

	/**
	 * Caller has to call it to let command execution to happen in synchronous
	 * fashion.
	 * <p>
	 * Synchronous - {@link HystrixCommand#execute()} runs
	 * {@link HystrixCommand#queue() get()} internally , hence posing
	 * synchronous calling as each Hystrix spawned thread will block Until it
	 * completes.
	 * </p>
	 *
	 * @return <R>
	 */
	public final R submit() {
		return execute();
	}
}
