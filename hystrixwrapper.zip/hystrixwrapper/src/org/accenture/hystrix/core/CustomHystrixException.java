
package org.accenture.hystrix.core;

/**
 * A custom exception ,thrown while executing Hystrix Commands
 *
 */
public class CustomHystrixException extends RuntimeException {

	private static final long serialVersionUID = 5486224318482556695L;

	/**
	 * Public Constructor
	 */
	public CustomHystrixException() {
		super();
	}

	/**
	 * Wrapping of exception in CustomHystrixException.
	 * 
	 * @param exception
	 *            - exception
	 */
	public CustomHystrixException(final Throwable exception) {
		super(exception);
	}

	/**
	 * Wrapping of message in CustomHystrixException.
	 * 
	 * @param message
	 *            - message associated with exception
	 */
	public CustomHystrixException(final String message) {
		super(message);
	}

	/**
	 * Wrapping up message and exception in CustomHystrixException
	 * 
	 * @param message
	 *            - message associated with exception
	 * @param exception
	 *            -exception
	 */
	public CustomHystrixException(final String message, final Throwable exception) {
		super(message, exception);
	}
}
