
package org.accenture.hystrix.core;

import org.apache.commons.lang.StringUtils;

/**
 * This <tt>Class</tt> keeps hold of all Hytrix command groups , each custom
 * Hystrix command should be associated to.
 *
 */
public enum CommandGroup {

	PAYPAL("paypalGroupCommandKey"), CYBER_SOURCE("cyberSourceCommandGroup"), TEST_SERVICE("testServiceCommandGroup");

	private final String commandGroupKey;

	private CommandGroup(final String commandGroupKey) {
		this.commandGroupKey = commandGroupKey;
	}

	/**
	 * @return the commandGroupKey
	 */
	public String getCommandGroupKey() {
		return commandGroupKey;
	}

	/**
	 * Returns <tt>RLHystrixCommandGroup</tt> enum for supplied command group
	 * key string.
	 *
	 * @param commandGroupKey
	 *            -hystrix collates all commands under this name for metrics
	 *            thread pool and caching purposes.
	 * @return {@code CommandGroup} - for supplied command group key
	 * 
	 */
	public static CommandGroup fromString(final String commandGroupKey) {
		if (StringUtils.isEmpty(commandGroupKey)) {
			throw new IllegalArgumentException("Supplied agrument can not be empty/null");
		}
		for (final CommandGroup commandGroup : values()) {
			if (StringUtils.equalsIgnoreCase(commandGroupKey, commandGroup.getCommandGroupKey())) {
				return commandGroup;
			}
		}
		return TEST_SERVICE;
	}

}
