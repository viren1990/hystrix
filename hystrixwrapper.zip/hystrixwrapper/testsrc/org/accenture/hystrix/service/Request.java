package org.accenture.hystrix.service;

import java.util.Map;

@SuppressWarnings("javadoc")
public class Request {

	private Map<String, Object> parameters;

	public Map<String, Object> getParameters() {
		return parameters;
	}

	public Request setParameters(Map<String, Object> parameters) {
		this.parameters = parameters;
		return this;
	}

}
