package org.accenture.hystrix.service;

import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.accenture.hystrix.service.command.TestAsyncServiceCommand;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestAsyncService implements Service {

	private static final Logger LOG = LoggerFactory.getLogger(org.accenture.hystrix.service.TestAsyncService.class);

	@Override
	public Optional<Reply> execute(final Request request) {
		final TestAsyncServiceCommand command = new TestAsyncServiceCommand("testServiceCommandGroup", "testServiceAsyncCommandKey", request);
		final Future<Reply> future = command.submit();

		try {
			return Optional.ofNullable(future.get());
		} catch (InterruptedException | ExecutionException e) {
			LOG.error(ExceptionUtils.getStackTrace(e));
		}
		return Optional.empty();
	}

}
