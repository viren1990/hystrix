package org.accenture.hystrix.service;

import java.util.Optional;

public interface Service {

	Optional<Reply> execute(Request request);

}
