package org.accenture.hystrix.service;

import java.util.Optional;

import org.accenture.hystrix.service.command.TestSyncServiceCommand;

/**
 *
 * A test service
 *
 */
public class TestSyncService implements Service {

	@Override
	public Optional<Reply> execute(final Request request) {
		final TestSyncServiceCommand syncCommand = new TestSyncServiceCommand("testServiceCommandGroup", "testServiceSyncCommandKey", request);
		return Optional.ofNullable(syncCommand.submit());
	}

}
