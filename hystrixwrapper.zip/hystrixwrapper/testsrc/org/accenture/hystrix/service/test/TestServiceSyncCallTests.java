package org.accenture.hystrix.service.test;

import de.hybris.bootstrap.annotations.UnitTest;

import java.util.Collections;
import java.util.Optional;

import org.accenture.hystrix.service.Reply;
import org.accenture.hystrix.service.Reply.Error;
import org.accenture.hystrix.service.Request;
import org.accenture.hystrix.service.Service;
import org.accenture.hystrix.service.TestSyncService;
import org.apache.commons.collections4.CollectionUtils;
import org.junit.Assert;
import org.junit.Test;

@UnitTest
public class TestServiceSyncCallTests {

	@Test
	public void testExecute_pass() {
		final Service syncService = new TestSyncService();
		final Optional<Reply> replyOptional = syncService.execute(new Request().setParameters(Collections.emptyMap()));

		Assert.assertTrue(replyOptional.isPresent());

		final Reply reply = replyOptional.get();
		Assert.assertEquals(100, reply.getReasonCode());
		Assert.assertTrue(CollectionUtils.isEmpty(reply.getErrors()));
	}

	@Test
	public void testExecute_fail() {
		final Service syncService = new TestSyncService();
		final Optional<Reply> replyOptional = syncService.execute(null);

		Assert.assertTrue(replyOptional.isPresent());

		final Reply reply = replyOptional.get();
		Assert.assertEquals(102, reply.getReasonCode());
		Assert.assertTrue(CollectionUtils.isNotEmpty(reply.getErrors()));
		Assert.assertTrue(Integer.compare(reply.getErrors().size(), 1) == 0);

		final Error error = reply.getErrors().iterator().next();
		Assert.assertTrue(error.getException() instanceof NullPointerException);
	}

}
