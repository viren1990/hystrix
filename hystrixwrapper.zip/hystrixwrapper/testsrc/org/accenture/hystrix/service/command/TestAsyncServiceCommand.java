package org.accenture.hystrix.service.command;

import java.util.Arrays;
import java.util.Objects;

import org.accenture.hystrix.core.AbstractQueueCommand;
import org.accenture.hystrix.service.Client;
import org.accenture.hystrix.service.Reply;
import org.accenture.hystrix.service.Reply.Error;
import org.accenture.hystrix.service.Request;
import org.apache.commons.lang.exception.ExceptionUtils;

@SuppressWarnings("javadoc")
public class TestAsyncServiceCommand extends AbstractQueueCommand<Reply> {

	private final Request request;

	public TestAsyncServiceCommand(final String commandGroupKey, final String commandKey, final Request request) {
		super(commandGroupKey, commandKey);
		this.request = request;
	}

	@Override
	public Reply doWork() {
		Objects.requireNonNull(this.request, "Request can not be null");
		final Client client = new Client();
		return client.call(this.request);
	}

	@Override
	public Reply fallback() {
		final Error error = new Error();
		error.setErrorCode("ERR_01");
		error.setException(getExecutionException());
		error.setErrorDescription(ExceptionUtils.getStackTrace(getExecutionException()));
		return new Reply().setReasonCode(102).setMessage("Exception occurred while command execution.").setErrors(Arrays.asList(error));
	}

	@Override
	public boolean shouldCommandRun() {
		return true;
	}

}
