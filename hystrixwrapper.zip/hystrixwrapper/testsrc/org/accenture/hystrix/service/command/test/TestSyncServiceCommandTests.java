package org.accenture.hystrix.service.command.test;

import de.hybris.bootstrap.annotations.UnitTest;

import org.accenture.hystrix.service.command.TestSyncServiceCommand;
import org.junit.Assert;
import org.junit.Test;

@UnitTest
public class TestSyncServiceCommandTests {

	@Test
	public void testAsyncServiceCommand() {
		final TestSyncServiceCommand command = new TestSyncServiceCommand("testServiceCommandGroup", "testServiceSyncCommandKey", null);
		command.submit();
		Assert.assertTrue(command.isResponseFromFallback());
	}

}
