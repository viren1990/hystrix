package org.accenture.hystrix.service;

import java.util.Collections;

public class Client {

	public Reply call(Request request) {
		// do nothing with request , return stubbed response;
		return prepareStubResponse();
	}

	private Reply prepareStubResponse() {
		return new Reply().setReasonCode(100).setMessage("Call executed successfully").setErrors(Collections.emptyList());
	}

}
