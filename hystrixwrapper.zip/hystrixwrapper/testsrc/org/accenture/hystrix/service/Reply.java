package org.accenture.hystrix.service;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

@SuppressWarnings("javadoc")
public class Reply {

	private int reasonCode;

	private String message;

	private List<Error> errors;

	public int getReasonCode() {
		return reasonCode;
	}

	public Reply setReasonCode(int reasonCode) {
		this.reasonCode = reasonCode;
		return this;
	}

	public String getMessage() {
		return message;
	}

	public Reply setMessage(String message) {
		this.message = message;
		return this;
	}

	public List<Error> getErrors() {
		return errors;
	}

	public Reply setErrors(List<Error> errors) {
		this.errors = errors;
		return this;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public static class Error {

		private String errorCode;

		private String errorDescription;

		private Throwable exception;

		public String getErrorCode() {
			return errorCode;
		}

		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}

		public String getErrorDescription() {
			return errorDescription;
		}

		public void setErrorDescription(String errorDescription) {
			this.errorDescription = errorDescription;
		}

		public Throwable getException() {
			return exception;
		}

		public void setException(Throwable exception) {
			this.exception = exception;
		}

		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this);
		}

	}
}